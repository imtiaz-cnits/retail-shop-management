<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Purchase extends Model
{
    use HasFactory;
    protected $fillable = [
        'purchase_id',
        'referance_no',
        'date',
        'grand_subtotal',
        'attach_document',
        'purchase_payable_amount',
        'supplier_id',
        'user_id'
    ];

    // One Purchase has many PurchaseOrderDetails
    public function orderDetails()
    {
        return $this->hasMany(PurchaseOrderDetails::class, 'purchase_id');
    }




    public function paymentDetails()
    {
        return $this->hasManyThrough(
            PurchasePaymentDetails::class,
            PurchaseOrderDetails::class,
            'purchase_id',
            'purchase_order_details_id',
            'id',
            'id'
        );
    }


    // One Purchase belongs to one Supplier
    public function supplier()
    {
        return $this->belongsTo(Supplier::class, 'supplier_id');
    }

}
