<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PurchasePaymentDetails extends Model
{
    use HasFactory;
    protected $fillable = [
        'payment_method',
        'paid_amount',
        'due_amount',
        'payment_status',
        'purchase_order_details_id',
        'user_id'
    ];

        // Each PaymentDetails belongs to one Purchase
        public function orderDetails()
    {
        return $this->belongsTo(PurchaseOrderDetails::class, 'purchase_order_details_id');
    }
}
