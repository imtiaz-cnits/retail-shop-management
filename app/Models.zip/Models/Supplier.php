<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{
    protected $fillable = [
        'supplier_id',
        'name',
        'company',
        'mobile',
        'address',
        'email',
        'img_url',
        'purchase_payable_amount',
        'status',
        'user_id'
    ];

    public function products()
    {
        return $this->hasMany(Product::class, 'suppliers_id');
    }

        // A Supplier has many Purchases
        public function purchases()
        {
            return $this->hasMany(Purchase::class, 'supplier_id');
        }

// Supplier Model
public function supplierDueCollections()
{
    return $this->hasMany(SupplierDueCollection::class, 'supplier_id', 'id');
}


}
