<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;
    protected $fillable = [
        'category_name',
        'img_url',
        'status',
        'user_id',
    ];

    public function products()
    {
        return $this->hasMany(Product::class, 'category_id');
    }
}
